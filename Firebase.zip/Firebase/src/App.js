import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Authen from './Authen';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <a href='./index.js'><img src={logo} className="App-logo" alt="logo" /></a>
          <h2>Welcome to React Firebase Login</h2>
        </div>
        <Authen />
      </div>
    );
  }
}

export default App;
