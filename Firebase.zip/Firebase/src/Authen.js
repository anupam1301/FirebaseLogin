import React, { Component } from 'react';
import Usurvey from './Usurvey';


var firebase = require('firebase');
var config = {
    apiKey: "AIzaSyCCCjysywh1c5gJVj7r3wIvWVvbEGTHjWE",
    authDomain: "usurvey-418e3.firebaseapp.com",
    databaseURL: "https://usurvey-418e3.firebaseio.com",
    projectId: "usurvey-418e3",
    storageBucket: "usurvey-418e3.appspot.com",
    messagingSenderId: "111455146666"
  };
  firebase.initializeApp(config);


class Authen extends Component {

  logout(event){
    firebase.auth().signOut();

    var err="Thank you for loging in.";

    this.setState({err: ''});
    alert(err);

    var lout=document.getElementById('logout');
    lout.classList.add('hide');

    var usur=document.getElementById('usur');
    usur.classList.add('hide');
  }

  signup(event){
    const email = this.refs.email.value;
    const password=this.refs.password.value;
    const auth= firebase.auth();
    const promise=auth.createUserWithEmailAndPassword(email,password);

    promise
    .then(user =>{
      var err="Welcome "+user.email;
      firebase.database().ref('users/'+user.uid).set({
        email: user.email
      });
      this.setState({err: err});

      });

    promise
    .catch(e =>{
      var err= e.message;
      this.setState({err: err});
      });

  }

  login(event){




    const email = this.refs.email.value;
    const password=this.refs.password.value;
    const auth= firebase.auth();
    const promise= auth.signInWithEmailAndPassword(email,password);

    promise
    .then(user =>{

      var lout=document.getElementById('logout');
      lout.classList.remove('hide');
      var usur=document.getElementById('usur');
      usur.classList.remove('hide');
      var err="Welcome "+user.email;
      this.setState({
          err: err

        });
      });

    promise.catch(e =>{
      var err= e.message;

      this.setState({display: ''});
      this.setState({err: err});
    });

    var display =<div id="usur" >
      <div className='card'><Usurvey /></div>
      </div>;
      this.setState({display: display});

  }

  constructor(props){
    super(props);

    this.state = {
      err: '',
      display: ''

    };

    this.login=this.login.bind(this);
    this.signup=this.signup.bind(this);
    this.logout=this.logout.bind(this);
  }
  render(){
    return(
      <div>
        <input id='email' ref='email' type='email' placeholder='Enter your email' /><br />
        <input id='pass' ref='password' type='password' placeholder='Enter your password' /><br />
        <p>{this.state.err}</p>
        <button onClick={this.login}>Log In</button>

        <button onClick={this.signup}>Sign Up</button>
        <button onClick={this.logout} id="logout" className='hide'>Log Out</button>
        {this.state.display}
      </div>
    );
  }
}

export default Authen;
